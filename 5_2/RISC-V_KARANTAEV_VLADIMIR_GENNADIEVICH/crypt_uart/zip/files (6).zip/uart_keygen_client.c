/*
 * uart_keygen_client.c
 *
 * Хост-клиент для взаимодействия с сервисом генерации ключей AES-256,
 * работающим на Zephyr RTOS внутри симуляции Verilator.
 *
 * Клиент подключается к псевдотерминалу /dev/pts/XXX,
 * отправляет команды и принимает ответы.
 *
 * Поддерживаемые команды:
 *   GENKEY  — запросить генерацию нового AES-256 ключа
 *   STATUS  — проверить готовность сервиса
 *   EXIT    — завершить работу сервиса
 *
 * Сборка:
 *   gcc -o uart_keygen_client uart_keygen_client.c
 *
 * Запуск:
 *   ./uart_keygen_client /dev/pts/XXX
 *
 * Интерактивный режим: клиент принимает команды из stdin.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <errno.h>
#include <time.h>

#define RESPONSE_BUF_SIZE 256
#define TIMEOUT_SEC       60

/*
 * Настройка PTY в raw-режим.
 * Отключает echo, canonical mode, обработку управляющих символов.
 */
static int configure_pty(int fd)
{
    struct termios tty;

    if (tcgetattr(fd, &tty) != 0) {
        perror("tcgetattr");
        return -1;
    }

    cfmakeraw(&tty);
    tty.c_cc[VMIN]  = 0;
    tty.c_cc[VTIME] = 10;  /* 1 секунда таймаут на read */

    if (tcsetattr(fd, TCSANOW, &tty) != 0) {
        perror("tcsetattr");
        return -1;
    }

    return 0;
}

/*
 * Отправить команду в UART побайтово.
 * Добавляет '\n' в конце (разделитель команд в протоколе).
 * Пауза между байтами для Verilator.
 */
static int send_command(int fd, const char *cmd)
{
    printf("[TX] >>> %s\n", cmd);

    for (int i = 0; cmd[i] != '\0'; i++) {
        if (write(fd, &cmd[i], 1) != 1) {
            perror("write");
            return -1;
        }
        usleep(100000);  /* 100 мс между байтами */
    }

    /* Отправить '\n' — конец команды */
    char newline = '\n';
    if (write(fd, &newline, 1) != 1) {
        perror("write newline");
        return -1;
    }

    return 0;
}

/*
 * Прочитать ответ от сервиса до символа '\n'.
 * Возвращает длину ответа (без '\n').
 */
static int receive_response(int fd, char *buf, int max_len)
{
    int pos = 0;
    time_t start = time(NULL);

    while (pos < max_len - 1) {
        if (time(NULL) - start > TIMEOUT_SEC) {
            printf("[RX] Таймаут ожидания ответа.\n");
            break;
        }

        char c;
        ssize_t n = read(fd, &c, 1);

        if (n == 1) {
            if (c == '\n') {
                break;  /* Конец ответа */
            }
            buf[pos++] = c;
        } else if (n == 0 || (n < 0 && errno == EAGAIN)) {
            usleep(50000);  /* 50 мс, ждём данных */
        } else {
            perror("read");
            return -1;
        }
    }

    buf[pos] = '\0';
    return pos;
}

/*
 * Ожидание строки "READY" от сервиса при запуске.
 * Zephyr-сервис отправляет "READY\n" после инициализации PSA Crypto.
 */
static int wait_for_ready(int fd)
{
    char buf[RESPONSE_BUF_SIZE];
    time_t start = time(NULL);

    printf("Ожидание готовности сервиса...\n");

    while (time(NULL) - start < TIMEOUT_SEC) {
        int len = receive_response(fd, buf, sizeof(buf));
        if (len > 0) {
            if (strcmp(buf, "READY") == 0) {
                printf("Сервис готов к работе.\n");
                return 0;
            }
            /* Игнорируем загрузочные сообщения Zephyr (printk) */
        }
    }

    printf("Таймаут: сервис не ответил READY.\n");
    return -1;
}

/*
 * Валидация hex-ключа AES-256.
 * Ключ должен быть ровно 64 hex-символа (32 байта = 256 бит).
 */
static int validate_aes256_hex_key(const char *hex_key)
{
    int len = strlen(hex_key);
    if (len != 64) {
        return -1;
    }

    for (int i = 0; i < len; i++) {
        char c = hex_key[i];
        if (!((c >= '0' && c <= '9') ||
              (c >= 'A' && c <= 'F') ||
              (c >= 'a' && c <= 'f'))) {
            return -1;
        }
    }

    return 0;
}

/*
 * Обработка ответа на команду GENKEY.
 * Ожидаемый формат: "KEY:<64 hex символа>"
 */
static void process_genkey_response(const char *response)
{
    if (strncmp(response, "KEY:", 4) == 0) {
        const char *hex_key = response + 4;

        if (validate_aes256_hex_key(hex_key) == 0) {
            printf("[OK] Получен AES-256 ключ:\n");
            printf("     %s\n", hex_key);
            printf("     Длина: 256 бит (32 байта)\n");
        } else {
            printf("[ERR] Некорректный формат ключа: %s\n", hex_key);
        }
    } else if (strncmp(response, "ERR:", 4) == 0) {
        printf("[ERR] Ошибка сервиса: %s\n", response + 4);
    } else {
        printf("[???] Неожиданный ответ: %s\n", response);
    }
}

/*
 * Вывести справку по командам.
 */
static void print_help(void)
{
    printf("\n");
    printf("  Доступные команды:\n");
    printf("  GENKEY  — генерация нового AES-256 ключа\n");
    printf("  STATUS  — проверка готовности сервиса\n");
    printf("  EXIT    — завершение сервиса и клиента\n");
    printf("  help    — эта справка\n");
    printf("  quit    — выход из клиента (без остановки сервиса)\n");
    printf("\n");
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "Использование: %s /dev/pts/XXX\n", argv[0]);
        return 1;
    }

    const char *pts_path = argv[1];

    /* Открытие псевдотерминала */
    printf("=== AES-256 Key Generation Client ===\n\n");
    printf("Подключение к %s...\n", pts_path);

    int fd = open(pts_path, O_RDWR | O_NOCTTY);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    if (configure_pty(fd) != 0) {
        close(fd);
        return 1;
    }

    /* Пауза и сброс буфера */
    sleep(1);
    tcflush(fd, TCIOFLUSH);

    /* Ожидание готовности сервиса */
    if (wait_for_ready(fd) != 0) {
        close(fd);
        return 1;
    }

    /* Интерактивный цикл */
    printf("\nВведите команду (help — справка):\n");
    print_help();

    char input[CMD_BUF_SIZE];
    char response[RESPONSE_BUF_SIZE];

    while (1) {
        printf("> ");
        fflush(stdout);

        if (fgets(input, sizeof(input), stdin) == NULL) {
            break;
        }

        /* Убрать '\n' из ввода */
        input[strcspn(input, "\n")] = '\0';

        /* Пустой ввод */
        if (strlen(input) == 0) {
            continue;
        }

        /* Локальные команды клиента */
        if (strcmp(input, "help") == 0) {
            print_help();
            continue;
        }
        if (strcmp(input, "quit") == 0) {
            printf("Выход из клиента.\n");
            break;
        }

        /* Отправка команды в сервис */
        if (send_command(fd, input) != 0) {
            printf("Ошибка отправки команды.\n");
            continue;
        }

        /* Приём ответа */
        int len = receive_response(fd, response, sizeof(response));
        if (len > 0) {
            printf("[RX] <<< %s\n", response);

            /* Специальная обработка для GENKEY */
            if (strcmp(input, "GENKEY") == 0) {
                process_genkey_response(response);
            }
        } else {
            printf("[RX] Нет ответа от сервиса.\n");
        }

        /* Если отправили EXIT — выходим */
        if (strcmp(input, "EXIT") == 0) {
            printf("Сервис завершён.\n");
            break;
        }
    }

    close(fd);
    return 0;
}
